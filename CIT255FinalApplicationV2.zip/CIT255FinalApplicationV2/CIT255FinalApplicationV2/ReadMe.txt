﻿Thresa Schultz 
CIT255FinalApplicationV2
December 11, 2017
TCWineJournal 
Console Application with XML persistance