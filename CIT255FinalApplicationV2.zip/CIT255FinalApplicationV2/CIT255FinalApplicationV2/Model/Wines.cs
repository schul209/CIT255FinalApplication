﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace CIT255FinalApplicationV2
{
    [XmlRoot("Wines")]
    public class Wines
    {
        [XmlElement("Wines")]
        public List<Wine> wines = new List<Wine>();
    }
}

