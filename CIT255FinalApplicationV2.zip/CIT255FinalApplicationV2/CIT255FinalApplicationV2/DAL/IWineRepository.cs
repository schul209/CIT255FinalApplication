﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CIT255FinalApplicationV2
{
    interface IWineRepository : IDisposable
    {
        Wine SelectByID(int id);
        List<Wine> SelectAll();
        void Insert(Wine wine);
        void Update(Wine wine);
        void Delete(int ID);

    }
}
