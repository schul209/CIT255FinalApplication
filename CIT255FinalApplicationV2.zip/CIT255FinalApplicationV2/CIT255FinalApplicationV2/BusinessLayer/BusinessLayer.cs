﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CIT255FinalApplicationV2
{
    class BusinessLayer : IDisposable
    {
        IWineRepository _wineRepository;

        public void WineBusiness(IWineRepository repository)
        {
            _wineRepository = repository;
        }
        public void Insert(Wine wine)
        {
            _wineRepository.Insert(wine);
        }
        public void Delete(int ID)
        {
            _wineRepository.Delete(ID);
        }
        public void Update(Wine wine)
        {
            _wineRepository.Update(wine);
        }
        public Wine SelectByID(int id)
        {
            return _wineRepository.SelectByID(id);
        }
        public List<Wine> SelectAll()
        {
            return _wineRepository.SelectAll();
        }
        //public List<Wine> QueryByVertical(int minimumVertical, int maximumVertical)
        //{
        //    List<Wine> wines = _wineRepository.SelectAll();

        //    return wines.Where(sr => sr.Vertical >= minimumVertical && sr.Vertical <= maximumVertical).ToList();
        //}
        public void Dispose()
        {
            _wineRepository = null;
        }
    }
}
