﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CIT255FinalApplication.Models
{
    class Wines
    {
        [XmlRoot("Wines")]
        public class SkiRuns
        {
            [XmlElement("Wines")]
            public List<Wine> skiRuns = new List<Wine>();
        }
    }
}
