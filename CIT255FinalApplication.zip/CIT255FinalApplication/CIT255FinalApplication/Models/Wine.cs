﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CIT255FinalApplication
{
    public  class Wine
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Vintage { get; set; }
        public string Vintner { get; set; }
        public string Sweetness { get; set; }
        public string Acidity { get; set; }
        public string Tannins { get; set; }
        public string Balance { get; set; }
        
        public Wine()
        {

        }

        public Wine(int id, string name, int vintage, string vintner, string sweetness, string acidity, string tannins, string balance)
        {
            this.ID = id;
            this.Name = name;
            this.Vintage = vintage;
            this.Vintner = vintner;
            this.Sweetness = sweetness;
            this.Acidity = acidity;
            this.Tannins = tannins;
            this.Balance = balance; 
        }
    }
}
