﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CIT255FinalApplication
{
    interface IWineRepository : IDisposable
    {
        Wine.SelectByID(int userID);
        List<Wine> SelectAll();
        void Insert(Wine wine);
        void Update(Wine wine);
        void Delete(int ID);

    }
}
