﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Data;


namespace CIT255FinalApplication
{
    public class WineRepositorySQL : IWineRepository
    {
        private IEnumerable<Wine> _wines = new List<Wine>();

        public WineRepositorySQL()
        {
            _wines = ReadAllWines();
        }

        private IEnumerable<Wine> ReadAllWines()
        {
            IList<Wine> wines = new List<Wine>();

            string connString = GetConnectionString();
            string sqlCommandString = "SELECT * from WineTable";

            using (SqlConnection sqlConn = new SqlConnection(connString))
            using (SqlCommand sqlCommand = new SqlCommand(sqlCommandString, sqlConn))
            {
                try
                {
                    sqlConn.Open();
                    using (SqlDataReader reader = sqlCommand.ExecuteReader())
                    {
                        if (reader != null)
                        {
                            while (reader.Read())
                            {
                                Wine wine = new Wine();
                                wine.ID = Convert.ToInt32(reader["ID"]);
                                wine.Name = reader["Name"].ToString();
                                wine.Vintage = Convert.ToInt32(reader["Vintage"]);
                                wine.Vintner = reader["Vintner"].ToString();
                                wine.Sweetness = reader["Sweetness"].ToString();
                                wine.Acidity = reader["Acidity"].ToString();
                                wine.Tannins = reader["Tannins"].ToString();
                                wine.Balance = reader["Balance"].ToString(); 

                                wines.Add(wine);
                            }
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    Console.WriteLine("SQL Exception: {0}", sqlEx.Message);
                    Console.WriteLine(sqlCommandString);
                }
            }

            return wines;
        }

        /// <summary>
        /// method to return a ski run given the ID
        /// uses a DataSet to hold ski run info
        /// </summary>
        /// <param name="ID">int ID</param>
        /// <returns>ski run object</returns>
        public Wine SelectById(int Id)
        {
            return _wines.Where(sr => sr.ID == Id).FirstOrDefault();
        }

        /// <summary>
        /// method to return a list of ski runs
        /// uses a DataSet to hold ski run info
        /// </summary>
        /// <returns>list of ski run objects</returns>
        public List<Wine> SelectAll()
        {
            return _wines as List<Wine>;
        }

        /// <summary>
        /// method to add a new ski run
        /// </summary>
        /// <param name="skiRun"></param>
        public void Insert(Wine wine)
        {
            string connString = GetConnectionString();

            // build out SQL command
            var sb = new StringBuilder("INSERT INTO WineTable");
            sb.Append(" ([ID],[Name],[Vintage], [Vintner], [Sweetness] [Acidity], [Tannins])");
            sb.Append(" Values (");
            sb.Append("'").Append(wine.ID).Append("',");
            sb.Append("'").Append(wine.Name).Append("',");
            sb.Append("'").Append(wine.Vintage).Append("',");
            sb.Append("").Append(wine.Vintner).Append(",");
            sb.Append("").Append(wine.Sweetness).Append(",");
            sb.Append("").Append(wine.Acidity).Append(",");
            sb.Append("").Append(wine.Tannins).Append(",");

            string sqlCommandString = sb.ToString();

            using (SqlConnection sqlConn = new SqlConnection(connString))
            using (SqlDataAdapter sqlAdapter = new SqlDataAdapter())
            {
                try
                {
                    sqlConn.Open();
                    sqlAdapter.InsertCommand = new SqlCommand(sqlCommandString, sqlConn);
                    sqlAdapter.InsertCommand.ExecuteNonQuery();
                }
                catch (SqlException sqlEx)
                {
                    Console.WriteLine("SQL Exception: {0}", sqlEx.Message);
                    Console.WriteLine(sqlCommandString);
                }
            }
        }

        /// <summary>
        /// method to delete a ski run by ski run ID
        /// </summary>
        /// <param name="ID"></param>
        public void Delete(int ID)
        {
            string connString = GetConnectionString();

            // build out SQL command
            var sb = new StringBuilder("DELETE FROM WineTable");
            sb.Append(" WHERE ID = ").Append(ID);
            string sqlCommandString = sb.ToString();

            using (SqlConnection sqlConn = new SqlConnection(connString))
            using (SqlDataAdapter sqlAdapter = new SqlDataAdapter())
            {
                try
                {
                    sqlConn.Open();
                    sqlAdapter.DeleteCommand = new SqlCommand(sqlCommandString, sqlConn);
                    sqlAdapter.DeleteCommand.ExecuteNonQuery();
                }
                catch (SqlException sqlEx)
                {
                    Console.WriteLine("SQL Exception: {0}", sqlEx.Message);
                    Console.WriteLine(sqlCommandString);
                }
            }
        }

        /// <summary>
        /// method to update an existing ski run
        /// </summary>
        /// <param name="skiRun">ski run object</param>
        public void Update(Wine wine)
        {
            string connString = GetConnectionString();

            // build out SQL command
            var sb = new StringBuilder("UPDATE WineTable SET ");
            sb.Append("Name = '").Append(wine.Name).Append("', ");
            sb.Append("Vintage = ").Append(wine.Vintage).Append(" ");
            sb.Append("Vintner = '").Append(wine.Vintner).Append("', ");
            sb.Append("Sweetness = ").Append(wine.Sweetness).Append(" ");
            sb.Append("Acidity = '").Append(wine.Acidity).Append("', ");
            sb.Append("Tannins = ").Append(wine.Tannins).Append(" ");
            sb.Append("WHERE ");
            sb.Append("ID = ").Append(wine.ID);
            string sqlCommandString = sb.ToString();

            using (SqlConnection sqlConn = new SqlConnection(connString))
            using (SqlDataAdapter sqlAdapter = new SqlDataAdapter())
            {
                try
                {
                    sqlConn.Open();
                    sqlAdapter.UpdateCommand = new SqlCommand(sqlCommandString, sqlConn);
                    sqlAdapter.UpdateCommand.ExecuteNonQuery();
                }
                catch (SqlException sqlEx)
                {
                    Console.WriteLine("SQL Exception: {0}", sqlEx.Message);
                    Console.WriteLine(sqlCommandString);
                }
            }
        }

        /// <summary>
        /// method to query the data by the vertical of each ski run in feet
        /// </summary>
        /// <param name="minimumVertical">int minimum vertical</param>
        /// <param name="maximumVertical">int maximum vertical</param>
        /// <returns></returns>
        //public IEnumerable<Wine> QueryByVertical(int minimumVertical, int maximumVertical)
        //{
        //    return _skiRuns.Where(sr => sr.Vertical >= minimumVertical && sr.Vertical <= maximumVertical);
        //}  TODO RECONFIGURE QUery

        /// <summary>
        /// get the connection string by name
        /// </summary>
        /// <returns>string connection string</returns>
        private static string GetConnectionString()
        {
            // Assume failure.
            string returnValue = null;

            // Look for the name in the connectionStrings section.
            var settings = ConfigurationManager.ConnectionStrings["TCWineJournal_Local"];

            // If found, return the connection string.
            if (settings != null)
                returnValue = settings.ConnectionString;

            return returnValue;
        }

        /// <summary>
        /// method to handle the IDisposable interface contract
        /// </summary>
        public void Dispose()
        {
            _wines = null;
        }
    }
}
