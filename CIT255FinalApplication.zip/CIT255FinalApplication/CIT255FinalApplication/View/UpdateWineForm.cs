﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CIT255FinalApplication.View
{
    public partial class UpdateWineForm : Form
    {
        public UpdateWineForm()
        {
            InitializeComponent();
        }
        private static void UpdateWine()
        {
            WineRepositorySQL wineRepository = new WineRepositorySQL();
            Wine wine = new Wine();
            int wineID;

            using (wineRepository)
            {
                wine = wineRepository.SelectAll();
                wineID = ConsoleView.GetSkiRunID(skiRuns);
                skiRun = skiRunRepository.SelectById(skiRunID);
                skiRun = ConsoleView.UpdateSkiRun(skiRun);
                skiRunRepository.Update(skiRun);
            }
        }
    }
}
