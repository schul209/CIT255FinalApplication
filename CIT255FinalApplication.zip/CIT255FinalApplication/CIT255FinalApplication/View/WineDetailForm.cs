﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CIT255FinalApplication.View
{
    public partial class WineDetailForm : Form
    {
        public WineDetailForm()
        {
            InitializeComponent();
        }

        private static void DisplayWineDetail()
        {
            WineRepositorySQL wineRepository = new WineRepositorySQL();
            List<Wine> wines;
            Wine wine = new Wine();
            int wineID;

            using (wineRepository)
            {
                wines = wine.SelectAll();
                wineID = ConsoleView.GetSkiRunID(skiRuns);
                skiRun = skiRunRepository.SelectById(skiRunID);
            }

            ConsoleView.DisplaySkiRun(skiRun);
            ConsoleView.DisplayContinuePrompt();
        }


    }
}
