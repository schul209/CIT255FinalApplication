﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CIT255FinalApplication.View
{
    public  partial class ListWinesForm : Form
    {
        public ListWinesForm()
        {
            InitializeComponent();
        }

        private void ListWinesForm_Load(object sender, EventArgs e)
        {
            ListWines();
        }
        private static void ListWines()
        {
            WineRepositorySQL wineRepository = new WineRepositorySQL();
            List<Wine> wines;

            using (wineRepository)
            {
                wines = wineRepository.SelectAll();
                //ConsoleView.DisplayAllWines(wines);
                //ConsoleView.DisplayContinuePrompt();
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // ListWinesForm
            // 
            this.ClientSize = new System.Drawing.Size(951, 629);
            this.Name = "ListWinesForm";
            this.ResumeLayout(false);

        }
    }
    
}
