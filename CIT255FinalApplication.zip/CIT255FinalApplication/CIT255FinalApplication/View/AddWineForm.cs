﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CIT255FinalApplication.View
{
    public partial class AddWineForm : Form
    {
        public AddWineForm()
        {
            InitializeComponent();
        }
        private static void AddWine()
        {
            WineRepositorySQL wineRepository = new WineRepositorySQL();
            Wine wine = new Wine();

            using (wineRepository)
            {
                wineRepository.Insert(wine);
            }

        }

    }
}
