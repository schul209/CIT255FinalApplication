﻿using CIT255FinalApplication.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CIT255FinalApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        ListWinesForm listWinesForm = new ListWinesForm();
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            listWinesForm.Show(); 
        }
        WineDetailForm wineDetailForm = new WineDetailForm();
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            wineDetailForm.Show();
        }
    }
}
