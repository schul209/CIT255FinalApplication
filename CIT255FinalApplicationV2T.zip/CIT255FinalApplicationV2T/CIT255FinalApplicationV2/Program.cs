﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CIT255FinalApplicationV2;

namespace CIT255FinalApplicationV2
{
    class Program
    {
        static void Main(string[] args)
        {
            // add test data to the data file
            InitializeDataFileXML.AddTestData();
            // instantiate the controller
            Controller appController = new Controller();
        }
    }
}
