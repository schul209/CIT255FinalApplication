﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace CIT255FinalApplicationV2
{
    class InitializeDataFileXML
    {
        public static void AddTestData()
        {
            List<Wine> wines = new List<Wine>();

            // initialize the IList of high scores - note: no instantiation for an interface
            wines.Add(new Wine() { ID = 901 - 104, Name = "Aexerrois", Vintage = 2004, Vintner = "3 Lads", Sweetness = "Dry", Acidity = "crisp", Tannins = "None", Balance = "Fair" });
            wines.Add(new Wine() { ID = 901 - 112, Name = "Aexerrois", Vintage = 2006, Vintner = "Aura Cellars", Sweetness = "Dry", Acidity = "Crisp", Tannins = "None", Balance = "Fair" });
            wines.Add(new Wine() { ID = 902 - 102, Name = "Brut", Vintage = 2015, Vintner = "Grand Traverse Chateau", Sweetness = "Bone Dry", Acidity = "Fresh", Tannins = "Low", Balance = "Good" });
            wines.Add(new Wine() { ID = 904 - 101, Name = "Cabernet Franc", Vintage = 2014, Vintner = "Righ Foot Charlie's", Sweetness = "Medium Sweet", Acidity = "Fresh", Tannins = "Medium", Balance = "Unbalanced" });
            wines.Add(new Wine() { ID = 905 - 105, Name = "Cabernet Savignon", Vintage = 2015, Vintner = "Shooting Star Farms", Sweetness = "Off-dry", Acidity = "Smooth", Tannins = "Low", Balance = "Fair" });
            wines.Add(new Wine() { ID = 906 - 112, Name = "Chardonnay", Vintage = 2015, Vintner = "Aura Cellars", Sweetness = "Dry", Acidity = "Smooth", Tannins = "Low", Balance = "Fair" });
            wines.Add(new Wine() { ID = 906 - 112, Name = "Chardonnay", Vintage = 2017, Vintner = "Beautiful Lake Vineyards", Sweetness = "Off-Dry", Acidity = "Crisp", Tannins = "Low", Balance = "Good" });
            wines.Add(new Wine() { ID = 907 - 104, Name = "Cherry Port", Vintage = 2015, Vintner = "3 Lads", Sweetness = "Sweet", Acidity = "Smooth", Tannins = "Medium", Balance = "Fair" });
            wines.Add(new Wine() { ID = 910 - 103, Name = "Dessert Wine", Vintage = 2014, Vintner = "Chantilly", Sweetness = "Very Sweet", Acidity = "Smooth", Tannins = "None", Balance = "Unbalanced" });
            wines.Add(new Wine() { ID = 910 - 108, Name = "Dessert Wine", Vintage = 2012, Vintner = "Fryes Estate", Sweetness = "Very Sweet", Acidity = "Smooth", Tannins = "None", Balance = "Unbalanced" });
            wines.Add(new Wine() { ID = 911 - 101, Name = "Gewurtztraminer", Vintage = 2017, Vintner = "Grand Traverse Chateau", Sweetness = "Medium", Acidity = "Fresh", Tannins = "Low", Balance = "Fair" });
            wines.Add(new Wine() { ID = 912 - 102, Name = "Gewurtztraminer", Vintage = 2015, Vintner = "Chantilly", Sweetness = "Off Dry", Acidity = "Fresh", Tannins = "Low", Balance = "Fair" });
            wines.Add(new Wine() { ID = 913 - 101, Name = "Ice Wine", Vintage = 2016, Vintner = "Right Foot Charlies", Sweetness = "Sweet", Acidity = "Smooth", Tannins = "None", Balance = "Good" });
            wines.Add(new Wine() { ID = 913 - 107, Name = "Ice Wine", Vintage = 2012, Vintner = "Power Harbor", Sweetness = "Sweet", Acidity = "Smooth", Tannins = "None", Balance = "Good" });
            wines.Add(new Wine() { ID = 913 - 110, Name = "Ice Wine", Vintage = 2012, Vintner = "Maree Vineyards", Sweetness = "Sweet", Acidity = "Smooth", Tannins = "None", Balance = "Good" });
            wines.Add(new Wine() { ID = 915 - 107, Name = "Merlot", Vintage = 2016, Vintner = "Power Harbor", Sweetness = "Off Dry", Acidity = "Smooth", Tannins = "High", Balance = "Fair" });
            wines.Add(new Wine() { ID = 915 - 111, Name = "Merlot", Vintage = 2013, Vintner = "Schoolhouse Vineyards", Sweetness = "Dry", Acidity = "Fresh", Tannins = "Medium", Balance = "Fair" });

            WriteAllWines(wines, DataSettings.dataFilePath);
        }

        /// <summary>
        /// method to write all wine info to the data file
        /// </summary>
        /// <param name="wines">list of wine info</param>
        /// <param name="dataFilePath">path to the data file</param>
        public static void WriteAllWines(List<Wine> wines, string dataFilePath)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Wine>), new XmlRootAttribute("Wines"));

            StreamWriter sWriter = new StreamWriter(dataFilePath);

            using (sWriter)
            {
                serializer.Serialize(sWriter, wines);
            }
        }
    }
}
