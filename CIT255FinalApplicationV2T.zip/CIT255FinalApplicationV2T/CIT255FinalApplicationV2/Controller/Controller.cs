﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CIT255FinalApplicationV2;

namespace CIT255FinalApplicationV2
{
   public  class Controller
    {
        #region ENUMERABLES


        #endregion

        #region FIELDS

        bool active = true;
        static IWineRepository wineRepository;
        #endregion

        #region PROPERTIES


        #endregion

        #region CONSTRUCTORS

        public Controller()
        {
            wineRepository = new WineRepositoryXML();

            ApplicationControl();
            
        }

        #endregion

        #region METHODS

        private void ApplicationControl()
        {
            AppEnum.ManagerAction userActionChoice;

            ConsoleView.DisplayWelcomeScreen();

            while (active)
            {
                userActionChoice = ConsoleView.GetUserActionChoice();

                switch (userActionChoice)
                {
                    case AppEnum.ManagerAction.None:
                        break;

                    case AppEnum.ManagerAction.ListWines:
                        ListAllWines();
                       // listWines.Show();
                        break;

                    case AppEnum.ManagerAction.WineDetail:
                        DisplayWineDetail(); 
                       // wineDetail.Show();
                        break;

                    case AppEnum.ManagerAction.AddWine:
                        AddWine();
                       // addWine.Show();
                        break;

                    case AppEnum.ManagerAction.UpdateWine:
                        UpdateWine();
                        break;

                    case AppEnum.ManagerAction.RemoveWine:
                        DeleteWine();
                        break;

                    //case AppEnum.ManagerAction.SearchWines:
                    //    QuerySkiRunsByVertical();
                    //    break;

                    case AppEnum.ManagerAction.Quit:
                        active = false;
                        break;

                    default:
                        break;
                }


            }

                ConsoleView.DisplayExitPrompt();
        }

        private static void ListAllWines()
        {
            BusinessLayer wineBusiness = new BusinessLayer();
            List<Wine> wines;

            using (wineBusiness)
            {
                wines = wineBusiness.SelectAll();
                ConsoleView.DisplayAllWines(wines);
                ConsoleView.DisplayContinuePrompt();
            }
        }

        private static void DisplayWineDetail()
        {
            BusinessLayer wineBusiness = new BusinessLayer();
            List<Wine> wines;
            Wine wine = new Wine();
            int wineID;

            using (wineBusiness)
            {
                wines = wineBusiness.SelectAll();
                wineID = ConsoleView.GetWineID(wines);
                wine = wineBusiness.SelectByID(wineID);
            }

            ConsoleView.DisplayWine(wine);
            ConsoleView.DisplayContinuePrompt();
        }

        private static void AddWine()
        {
            BusinessLayer wineBusiness = new BusinessLayer();
            Wine wine = new Wine();

            wine = ConsoleView.AddWine();
            using (wineBusiness)
            {
                wineBusiness.Insert(wine);
            }

            ConsoleView.DisplayContinuePrompt();
        }

        private static void UpdateWine()
        {
            BusinessLayer wineBusiness = new BusinessLayer();
            List<Wine> wines = wineBusiness.SelectAll();
            Wine wine = new Wine();
            int wineID;

            using (wineRepository)
            {
                wines = wineBusiness.SelectAll();
                wineID = ConsoleView.GetWineID(wines);
                wine = wineBusiness.SelectByID(wineID);
                wine = ConsoleView.UpdateWine(wine);
                wineBusiness.Update(wine);
            }
        }

        private static void DeleteWine()
        {
            BusinessLayer wineBusiness = new BusinessLayer();
            List<Wine> wines = wineBusiness.SelectAll();
            Wine wine = new Wine();
            int wineID;
            string message;

            wineID = ConsoleView.GetWineID(wines);

            using (wineBusiness)
            {
                wineRepository.Delete(wineID);
            }

            ConsoleView.DisplayReset();

            // TODO refactor
            message = String.Format("Wine ID: {0} had been deleted.", wineID);

            ConsoleView.DisplayMessage(message);
            ConsoleView.DisplayContinuePrompt();
        }

        //private static void QuerySkiRunsByVertical()
        //{
        //    SkiRunRepositorySQL skiRunRepository = new SkiRunRepositorySQL();
        //    IEnumerable<SkiRun> matchingSkiRuns = new List<SkiRun>();
        //    int minimumVertical;
        //    int maximumVertical;

        //    ConsoleView.GetVerticalQueryMinMaxValues(out minimumVertical, out maximumVertical);

        //    using (skiRunRepository)
        //    {
        //        matchingSkiRuns = skiRunRepository.QueryByVertical(minimumVertical, maximumVertical);
        //    }

        //    ConsoleView.DisplayQueryResults(matchingSkiRuns);
        //    ConsoleView.DisplayContinuePrompt();
        //}

        #endregion

    }
}
