﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using CIT255FinalApplicationV2;

namespace CIT255FinalApplicationV2
{
    class WineRepositoryXML : IDisposable, IWineRepository
    {
        private List<Wine> _wines;

        public WineRepositoryXML()
        {
            _wines = ReadWineData(DataSettings.dataFilePath);
        }

        /// <summary>
        /// method to read all wine information from the data file a
        /// </summary>
        /// <param name="dataFilePath">path the data file</param>
        /// <returns>list of Wine objects</returns>
        public List<Wine> ReadWineData(string dataFilePath)
        {
            Wines winesFromFile = new Wines();

            // initialize a FileStream object for reading
            StreamReader sReader = new StreamReader(DataSettings.dataFilePath);

            // initialize an XML seriailizer object
            XmlSerializer deserializer = new XmlSerializer(typeof(Wines));

            using (sReader)
            {
                object xmlObject = deserializer.Deserialize(sReader);
                winesFromFile = (Wines)xmlObject;
            }

            return winesFromFile.wines;
        }

        /// <summary>
        /// method to write all of the list of wines to the text file
        /// </summary>
        public void Save()
        {
            // initialize a FileStream object for reading
            StreamWriter sWriter = new StreamWriter(DataSettings.dataFilePath, false);

            XmlSerializer serializer = new XmlSerializer(typeof(List<Wine>), new XmlRootAttribute("Wines"));

            using (sWriter)
            {
                serializer.Serialize(sWriter, _wines);
            }
        }

        /// <summary>
        /// method to add a new wine
        /// </summary>
        /// <param name="wine"></param>
        public void Insert(Wine wine)
        {
            _wines.Add(wine);

            Save();
        }

        /// <summary>
        /// method to delete a wine by ID
        /// </summary>
        /// <param name="ID"></param>
        public void Delete(int ID)
        {
            _wines.Remove(_wines.FirstOrDefault(sr => sr.ID == ID));

            Save();
        }

        /// <summary>
        /// method to update an existing wine
        /// </summary>
        /// <param name="wine">wine object</param>
        public void Update(Wine wine)
        {
            Delete(wine.ID);
            Insert(wine);

            Save();
        }

        /// <summary>
        /// method to return a wine object given the ID
        /// </summary>
        /// <param name="ID">int ID</param>
        /// <returns>wine object</returns>
        public  SelectByID(int ID)
        {
            Wine wine;

            wine =  _wines.FirstOrDefault(sr => sr.ID == ID);

             return wine; 
        }

        /// <summary>
        /// method to return a list of wine objects
        /// </summary>
        /// <returns>list of wine objects</returns>
        public List<Wine> SelectAll()
        {
            return _wines;
        }

        /// <summary>
        /// method to handle the IDisposable interface contract
        /// </summary>
        public void Dispose()
        {
            _wines = null;
        }
    }
}
